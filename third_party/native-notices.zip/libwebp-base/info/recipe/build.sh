#!/bin/bash
# Get an updated config.sub and config.guess
cp $BUILD_PREFIX/share/gnuconfig/config.* .
set -ex

cmake ${CMAKE_ARGS} -G Ninja -S . -B build \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=${PREFIX} \
    -DBUILD_SHARED_LIBS=ON \
    -DWEBP_BUILD_CWEBP:BOOL=OFF \
    -DWEBP_BUILD_DWEBP:BOOL=OFF \
    -DWEBP_BUILD_EXTRAS:BOOL=OFF \
    -DWEBP_BUILD_GIF2WEBP:BOOL=OFF \
    -DWEBP_BUILD_IMG2WEBP:BOOL=OFF \
    -DWEBP_BUILD_LIBWEBPMUX:BOOL=ON \
    -DWEBP_BUILD_VWEBP:BOOL=OFF \
    -DWEBP_BUILD_WEBP_JS:BOOL=OFF \
    -DWEBP_BUILD_WEBPINFO:BOOL=OFF \
    -DWEBP_BUILD_WEBPMUX:BOOL=OFF \
    -DWEBP_LINK_STATIC:BOOL=OFF

cmake --build build -j${CPU_COUNT}

cmake --install build --prefix ${PREFIX}
